!function(t){"use strict";t("a.page-scroll").bind("click",function(a){var o=t(this);t("html, body").stop().animate({scrollTop:t(o.attr("href")).offset().top-50},1250,"easeInOutExpo"),a.preventDefault()}),t("body").scrollspy({target:".navbar-fixed-top",offset:100}),t(".navbar-collapse ul li a").click(function(){t(".navbar-toggle:visible").click()}),t("#mainNav").affix({offset:{top:50}})}(jQuery);


  $(' .count').counterUp({
    delay:10,
    time:3000
  })

mybutton=document.getElementById("mybtn");

window.onscroll=function()
{
  scrollFunction()};

function scrollFunction(){
  if (document.body.scrollTop>20 || document.documentElement.scrollTop > 20){
    mybutton.style.display="block";
  }
  else{
    mybutton.style.display="none";
  }
}

function topFunction(){
  document.body.scrollTop=0;
  document.documentElement.scrollTop =0;
}

